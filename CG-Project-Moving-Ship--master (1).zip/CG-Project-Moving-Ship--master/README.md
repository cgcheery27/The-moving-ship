# CG-Project-Moving-Ship-

A animation made in openGL using codeblocks. In this mini project all the things and shapes and colors are drawn and filled from scratch 
there is no use of inbuilt openGL function.

Clone the project in your system which is having openGL configuration and then you are good to go and work on this mini animation.
